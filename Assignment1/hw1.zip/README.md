
This program can be run using the Driver class and a java compiler like used in the examples from the assignment description. 